package com.jaros.core;

/** Adapter boundary for GPT, Claude, a local model, or another provider. */
public interface IntelligenceProvider {
    String getName();
    boolean isConfigured();
    void ask(String prompt, Callback callback);

    interface Callback {
        void onSuccess(String answer);
        void onError(String message);
    }
}
