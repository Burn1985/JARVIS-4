package com.jaros.actions;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import com.jaros.core.AssistantResult;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Executes only low-risk, explicit Android hand-offs in this first alpha. */
public class AndroidActionExecutor {
    private final Activity activity;
    public AndroidActionExecutor(Activity activity) { this.activity = activity; }

    public AssistantResult tryExecute(String raw) {
        String q = raw == null ? "" : raw.trim();
        String s = q.toLowerCase(new Locale("ru", "RU"));
        try {
            if (s.contains("календар")) {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_APP_CALENDAR);
                activity.startActivity(i);
                return new AssistantResult("Передал Android команду открыть календарь.", true);
            }
            if (s.contains("будильник") || s.contains("разбуди")) {
                Matcher m = Pattern.compile("(\\d{1,2})[:.](\\d{2})").matcher(q);
                if (!m.find()) return new AssistantResult("Укажи время, например 07:30. Будильник пока не установлен.", false);
                int h = Integer.parseInt(m.group(1)), min = Integer.parseInt(m.group(2));
                if (h > 23 || min > 59) return new AssistantResult("Время некорректно. Будильник не установлен.", false);
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "ЖАРОС");
                activity.startActivity(i);
                return new AssistantResult(String.format(Locale.getDefault(), "Передал Android запрос на будильник %02d:%02d. Проверь и подтверди его в приложении часов.", h, min), true);
            }
            if (s.contains("youtube") || s.contains("ютуб")) {
                open("https://www.youtube.com/results?search_query=" + enc(q));
                return new AssistantResult("Открыл результаты поиска YouTube.", true);
            }
            if (s.contains("найди") || s.contains("поищи") || s.contains("поиск") || s.contains("google") || s.contains("гугл")) {
                open("https://www.google.com/search?q=" + enc(q));
                return new AssistantResult("Открыл поиск Google. Это веб-поиск, а не ответ ИИ.", true);
            }
        } catch (ActivityNotFoundException e) {
            return new AssistantResult("На телефоне не найдено приложение для этого действия.", false);
        } catch (Exception e) {
            return new AssistantResult("Не удалось передать команду Android: " + e.getClass().getSimpleName(), false);
        }
        return null;
    }
    private void open(String url) { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; } }
}
