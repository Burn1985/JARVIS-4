package com.jaros.core;

import android.content.Context;
import android.content.SharedPreferences;

/** Minimal on-device conversation note store. Not a secure vault for secrets. */
public class LocalMemory {
    private static final String PREFS = "jaros_local_memory";
    private final SharedPreferences prefs;
    public LocalMemory(Context context) { prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public void remember(String userText, String assistantText) {
        prefs.edit().putString("last_user", userText).putString("last_answer", assistantText).apply();
    }
    public String lastExchange() {
        String u = prefs.getString("last_user", "");
        String a = prefs.getString("last_answer", "");
        if (u.isEmpty()) return "Пока записей нет.";
        return "Последний запрос: " + u + "\nПоследний ответ: " + a;
    }
}
