package com.jaros.core;

import com.jaros.actions.AndroidActionExecutor;

/** Central coordinator. Provider calls are intentionally not faked in alpha1. */
public class AssistantCore {
    private final AndroidActionExecutor actions;
    private final LocalMemory memory;
    public AssistantCore(AndroidActionExecutor actions, LocalMemory memory) {
        this.actions = actions; this.memory = memory;
    }
    public AssistantResult process(String input) {
        String q = input == null ? "" : input.trim();
        if (q.isEmpty()) return new AssistantResult("Скажи или напиши, что нужно сделать.", false);
        if (q.equalsIgnoreCase("что ты помнишь") || q.equalsIgnoreCase("покажи память")) {
            return new AssistantResult(memory.lastExchange(), false);
        }
        AssistantResult action = actions.tryExecute(q);
        if (action != null) {
            memory.remember(q, action.message);
            return action;
        }
        String answer = "Я получил запрос: «" + q + "». Интеллектуальная модель ещё не подключена. " +
            "Архитектура ЖАРОС уже отделяет ядро от будущих GPT, Claude и локальных моделей; сейчас не буду притворяться, что ИИ ответил.";
        memory.remember(q, answer);
        return new AssistantResult(answer, false);
    }
}
