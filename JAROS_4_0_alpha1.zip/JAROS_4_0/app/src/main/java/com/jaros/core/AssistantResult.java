package com.jaros.core;

public class AssistantResult {
    public final String message;
    public final boolean actionStarted;
    public AssistantResult(String message, boolean actionStarted) {
        this.message = message;
        this.actionStarted = actionStarted;
    }
}
