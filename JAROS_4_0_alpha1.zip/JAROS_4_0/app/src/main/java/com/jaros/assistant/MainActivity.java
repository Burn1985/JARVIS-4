package com.jaros.assistant;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.util.TypedValue;
import com.jaros.actions.AndroidActionExecutor;
import com.jaros.core.AssistantCore;
import com.jaros.core.AssistantResult;
import com.jaros.core.LocalMemory;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 410;
    private AssistantCore core;
    private TextToSpeech tts;
    private EditText input;
    private TextView output, status;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,25,43));
        getWindow().setNavigationBarColor(Color.rgb(12,25,43));
        core = new AssistantCore(new AndroidActionExecutor(this), new LocalMemory(this));
        tts = new TextToSpeech(this, result -> {
            if (result != TextToSpeech.ERROR) ttsReady = tts.setLanguage(new Locale("ru", "RU")) >= 0;
        });

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(24));
        page.setBackgroundColor(Color.rgb(12,25,43));
        page.addView(label("ЖАРОС 4.0", 30, Color.WHITE, true));
        page.addView(label("Персональная интеллектуальная система · alpha 1", 14, 0xffb4c3d7, false));
        status = label("Ядро запущено · локальный режим", 13, 0xff75dcae, false);
        status.setPadding(0, dp(16), 0, dp(12)); page.addView(status);

        input = new EditText(this);
        input.setTextColor(Color.WHITE); input.setHintTextColor(0xff9aabc0);
        input.setHint("Напиши команду или вопрос…"); input.setTextSize(16);
        input.setMinLines(2); input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setBackgroundColor(0xff1d3048); page.addView(input, new LinearLayout.LayoutParams(-1, -2));

        Button send = button("ОБРАБОТАТЬ ЗАПРОС");
        send.setOnClickListener(v -> process(input.getText().toString()));
        page.addView(send, params());
        Button voice = button("🎙  ГОВОРИТЬ С ЖАРОС");
        voice.setOnClickListener(v -> listen()); page.addView(voice, params());
        Button memory = button("ПОКАЗАТЬ ПАМЯТЬ");
        memory.setOnClickListener(v -> process("покажи память")); page.addView(memory, params());

        output = label("Здесь появится результат.\n\nПроверка: «Открой календарь», «Поставь будильник на 07:30», «Найди новости Android».", 15, Color.WHITE, false);
        output.setPadding(dp(14), dp(16), dp(14), dp(16)); output.setBackgroundColor(0xff182a41);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, -2); op.topMargin = dp(16); page.addView(output, op);
        TextView disclaimer = label("В этой версии реальные локальные действия отделены от будущих ИИ-провайдеров. GPT/Claude пока не подключены. Секретные ключи в приложение не вшиваются.", 12, 0xffb1c1d6, false);
        disclaimer.setPadding(0, dp(16), 0, 0); page.addView(disclaimer);
        ScrollView scroll = new ScrollView(this); scroll.addView(page); setContentView(scroll);
    }
    private void process(String q) {
        AssistantResult r = core.process(q);
        output.setText("Запрос: " + q + "\n\nЖАРОС: " + r.message);
        status.setText(r.actionStarted ? "Команда передана исполнителю Android" : "Ответ сформирован локальным ядром");
        if (ttsReady) tts.speak(r.message, TextToSpeech.QUEUE_FLUSH, null, "jaros_reply");
    }
    private void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите команду для ЖАРОС");
        try { startActivityForResult(i, VOICE_REQUEST); }
        catch (Exception e) { status.setText("Сервис распознавания речи недоступен на устройстве."); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) { input.setText(list.get(0)); process(list.get(0)); }
        }
    }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private LinearLayout.LayoutParams params() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.topMargin = dp(7); return p; }
    private TextView label(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, 1); return t; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
