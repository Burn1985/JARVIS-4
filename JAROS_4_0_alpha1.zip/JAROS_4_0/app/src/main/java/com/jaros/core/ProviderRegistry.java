package com.jaros.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Keeps provider selection separate from the assistant's memory and action system. */
public class ProviderRegistry {
    private final List<IntelligenceProvider> providers = new ArrayList<>();
    public void register(IntelligenceProvider provider) { if (provider != null) providers.add(provider); }
    public List<IntelligenceProvider> all() { return Collections.unmodifiableList(providers); }
    public IntelligenceProvider getConfiguredDefault() {
        for (IntelligenceProvider p : providers) if (p.isConfigured()) return p;
        return null;
    }
}
